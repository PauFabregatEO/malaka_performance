#!/bin/bash
source /dtu/projects/02613_2025/conda/conda_init.sh
conda activate 02613

python -m line_profiler -rmt simulate.py.lprof